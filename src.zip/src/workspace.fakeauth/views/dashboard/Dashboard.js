import React from "react";

export function Dashboard() {
	return (
		<section>
			<h1>Dashboard</h1>
		</section>
	);
}
