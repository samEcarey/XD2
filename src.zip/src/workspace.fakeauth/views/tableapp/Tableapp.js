import React from "react";

export function Tableapp() {
	return (
		<section>
			<h1>Tableapp</h1>
		</section>
	);
}
