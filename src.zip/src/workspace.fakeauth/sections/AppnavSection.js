import React from "react";
import { Section } from "app/common";

export function AppnavSection() {
	return (
		<Section>
			<div>Appnav-section</div>
		</Section>
	);
}
