import React from "react";
import { Section } from "app/common";

export function AppviewSection() {
	return (
		<Section>
			<div>Appview-section</div>
		</Section>
	);
}
