# Framer Notes

- By default all transforms are 3d
- You should only animate transforms and opacity
- Translate shortcuts: x, y, z

- Translate: translateX, translateY, translateZ
- Scale: scale, scaleX, scaleY
- Rotate: rotate, rotateX, rotateY, rotateZ
- Skew: skew, skewX, skewY
