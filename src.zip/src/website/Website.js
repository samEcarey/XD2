import React from "react";

export function Website() {
	return (
		<section>
			<h1>Website</h1>
		</section>
	);
}
