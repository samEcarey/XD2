import React from "react";

export function Credit() {
	return (
		<small className="">2020 Extra Duty Solutions. All rights reserved.</small>
	);
}
