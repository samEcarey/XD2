import React from "react";

export function AuthNotLoggedInMsg() {
	return <p>You are not logged in.</p>;
}
