import React from "react";

export function ActionsUser() {
	return (
		<div className="Useractions-actionuser">
			<figure>
				<img src="https://placehold.it/40x40?text=User" />
			</figure>
			<div>
				<small>Welcome..</small>
				<span>Dan Ryanshavinsky</span>
			</div>
		</div>
	);
}
