import styled from "styled-components";

export const AppHeaderStyled = styled.header``;
