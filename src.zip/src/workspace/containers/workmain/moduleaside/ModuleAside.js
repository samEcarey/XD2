import React from "react";

export function ModuleAside() {
	return (
		<aside>
			<h4>Module Aside</h4>
		</aside>
	);
}
