# Features

## Features vs Modules

Features are standalone or are used by Modules.
