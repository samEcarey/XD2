import React from "react";
import { Container } from "../../components";

export function Workmain() {
	return (
		<Container.Workmain className="Container-workmain">
			<h1>Workmain</h1>
			<p>
				Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestias
				mollitia quasi obcaecati, harum doloribus assumenda neque facere
				provident. Unde, aut! Lorem ipsum dolor sit, amet consectetur
				adipisicing elit. Molestias mollitia quasi obcaecati, harum doloribus
				assumenda neque facere provident. Unde, aut!
			</p>
		</Container.Workmain>
	);
}
