import styled from "styled-components";

export const ActionsNavStyled = styled.nav`
	margin: 0rem 0rem 0rem 0rem;
	padding: 1rem 0rem 0rem 0rem;
	/* @media (min-width: 1024px) { } */
	/* background: green; */
`;
