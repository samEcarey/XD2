import styled from "styled-components";

export const GridSC = styled.section``;
