import React from "react";

export function Routes() {
	return (
		<div>
			<h1>Routes</h1>
		</div>
	);
}
