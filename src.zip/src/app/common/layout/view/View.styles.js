import styled from "styled-components";

export const ViewStyled = styled.div``;
