import styled from "styled-components";

export const ScreenStyled = styled.section``;
