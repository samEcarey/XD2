import styled from "styled-components";

export const RowStyled = styled.div``;
