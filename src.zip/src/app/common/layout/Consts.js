/** Colors */
export const COLOR_WHITE = "white";
export const COLOR_BLACK = "black";

/***** Margin/Padding *****/

/** Grid */
export const MARGIN_GRID = "";
export const PADDING_GRID = "";
