import styled from "styled-components";

export const SectionStyled = styled.section`
	h1 {
		margin: 0rem;
	}
`;
