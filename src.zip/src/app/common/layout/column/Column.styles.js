import styled from "styled-components";

export const ColumnStyled = styled.div``;
