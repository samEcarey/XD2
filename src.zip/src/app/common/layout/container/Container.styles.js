import styled from "styled-components";

export const ContainerStyled = styled.section``;
