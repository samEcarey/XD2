import styled from "styled-components";

export const FigureStyled = styled.figure`
	vertical-align: top;
	img {
		vertical-align: top;
	}
	/* background: red; */
`;
