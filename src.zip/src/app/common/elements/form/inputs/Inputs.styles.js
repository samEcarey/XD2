import styled from "styled-components";

export const InputStyled = styled.input``;
