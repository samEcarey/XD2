import React from "react";
import { StyledB } from "./Text.styles";

export const B = ({ children }) => {
	return <StyledB>{children}</StyledB>;
};
