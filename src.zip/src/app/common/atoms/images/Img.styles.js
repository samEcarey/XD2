import styled from 'styled-components'

export const StyledImg = styled.img`
	margin: 0rem 0rem 0rem 0rem;
	max-width: 100%;
`