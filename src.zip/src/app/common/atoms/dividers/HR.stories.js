import React from 'react';
import { action } from '@storybook/addon-actions'
import { HR } from './HR'

export const HRBasic = () => (
	<HR/>
)

export default {
	component: HR,
	title: 'Atoms',
}