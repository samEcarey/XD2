import React from 'react'
import { StyledHR } from './HR.styles'

export function HR() {
	return (
		<StyledHR/>
	)
}
