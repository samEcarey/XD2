import styled from "styled-components";

export const H6 = styled.h6``;
