import styled from "styled-components";

export const H4 = styled.h4``;
