import styled from "styled-components";

export const H3 = styled.h3``;
