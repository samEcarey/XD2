import styled from "styled-components";

export const H5 = styled.h5``;
