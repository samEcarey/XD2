export const XS = 414;
export const SM = 640;
export const MD = 768;
export const ML = 992;
export const LG = 1024;
export const XL = 1280;
