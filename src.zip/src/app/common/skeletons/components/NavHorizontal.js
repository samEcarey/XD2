import React from "react";

export function NavHorizontal() {
	return (
		<nav>
			<ul>
				<li>one</li>
				<li>two</li>
				<li>three</li>
			</ul>
		</nav>
	);
}
