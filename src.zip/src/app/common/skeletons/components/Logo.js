import React from "react";

export const Logo = ({ width, height, radius }) => {
	return (
		<figure width={} height={} radius={}>
			<img src="" alt="" title="" />
		</figure>
	);
};
