import React from "react";

export function NavVertical() {
	return (
		<nav>
			<ul>
				<li>one</li>
				<li>two</li>
				<li>three</li>
			</ul>
		</nav>
	);
}
