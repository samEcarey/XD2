//****** Base Colors *******/

export const COLOR_WHITE = "white"; // #FFFFFF - rbga(255, 255, 255, 1.0)
export const COLOR_BLACK = "black"; // #FFFFFF - rbga(0, 0, 0, 1.0)
