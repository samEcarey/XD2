export const GLOBAL_REM_FONT_SIZE = "62.5%";
export const GLOBAL_FONT_FAMILY =
	" 'Roboto', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif ";
export const GLOBAL_FONT_SIZE = "1.6em";
export const GLOBAL_FONT_WEIGHT = "300";
export const GLOBAL_LETTER_SPACING = ".01em";
export const GLOBAL_LINE_HEIGHT = "1.6";
