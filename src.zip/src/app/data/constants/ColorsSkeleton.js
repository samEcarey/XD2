export const LIGHT_TINT = "rgba(26, 29, 31, 0.4)"; // "rgba()";

export const SKELETON_COLOR = "rgba(26, 29, 31, 0.2)"; // "rgba()";
export const SKELETON_SHADE = "rgba(26, 29, 31, 0.3)"; // "rgba()";
export const SKELETON_TINT = "rgba(26, 29, 31, 0.1)"; // "rgba()";

export const SKELETON_BORDER_RADIUS = "1rem";
export const SKELETON_BORDER_RADIUS_CIRCLE = "2.5rem";
