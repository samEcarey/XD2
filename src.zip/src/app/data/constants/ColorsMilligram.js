//****** Milligram Colors *******/

export const PRIMARY_COLOR = "#9b4dca"; // "rgba()";
export const PRIMARY_SHADE = "#"; // "rgba()";
export const PRIMARY_TINT = "#"; // "rgba()";

export const SECONDARY_COLOR = "#606c76"; // "rgba()";
export const SECONDARY_SHADE = "#"; // "rgba()";
export const SECONDARY_TINT = "#"; // "rgba()";

export const TERTIARY_COLOR = "#f4f5f6"; // "rgba()";
export const TERTIARY_SHADE = "#"; // "rgba()";
export const TERTIARY_TINT = "#"; // "rgba()";

export const QUATERNARY_COLOR = "#d1d1d1"; // "rgba()";
export const QUATERNARY_SHADE = "#"; // "rgba()";
export const QUATERNARY_TINT = "#"; // "rgba()";

export const QUINARY_COLOR = "#e1e1e1"; // "rgba()";
export const QUINARY_SHADE = "#"; // "rgba()";
export const QUINARY_TINT = "#"; // "rgba()";

export const INITIAL_COLOR = "#fff";
