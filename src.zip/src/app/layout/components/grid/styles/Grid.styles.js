import styled from "styled-components";

export const GridSC = styled.section`
	display: grid;
	background-color: blue;
`;

export const GridTemplateSC = styled.section`
	background-color: orange;
`;
