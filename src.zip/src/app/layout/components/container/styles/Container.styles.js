import styled from "styled-components";

export const ContainerSC = styled.section`
	background-color: green;
`;
