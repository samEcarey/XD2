# Change the Tag

\* Add it on element as prop

\* Example: <Flex.Row as="ul">

- as = "section";
- as = "div";
- as = "header";
- as = "nav";
- as = "main";
- as = "article";
- as = "footer";
- as = "ul";
- as = "ol";
- as = "dl";
