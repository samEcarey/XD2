export const spacingMargin = {};

export const spacingPadding = {
  padding: "0rem 0rem 0rem 0rem",
};
