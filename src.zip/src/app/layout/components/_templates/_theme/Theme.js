import React from "react";
import { ThemeStyled } from "./Theme.styles";

export function Theme() {
  return <div></div>;
}
