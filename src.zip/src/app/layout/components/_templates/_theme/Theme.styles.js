import styled from "styled-components";

export const ThemeStyled = styled.div`
  @media (min-width: 1024px) {
  }
`;
