import styled from "styled-components";

export const EdsHatSvgStyled = styled.svg`
	display: block;
	vertical-align: top;
	fill: Blue;
	width: 38px;
	/* &:hover {
			fill: #fff;
			cursor: pointer;
		} */
`;
