export const drawerPushRightVariants = {
	open: { width: 300 },
	closed: { width: 0, overflowX: "hidden" }
};
