export const drawerLeftDesktopVariants = {
	open: { x: 0 },
	closed: { x: "-100%" }
};
