import styled from "styled-components";

export const EdsHatFigureStyled = styled.figure`
	display: inline-block;
	margin: 0;
	padding: 1rem 0rem 1.5rem 0.5rem;
	/* background: red; */
`;
