import styled from "styled-components";

export const EdsHatSvgStyled = styled.svg`
	display: block;
	vertical-align: top;
	fill: #232323;
	width: 38px;
	/* &:hover {
			fill: #fff;
			cursor: pointer;
		} */
`;
