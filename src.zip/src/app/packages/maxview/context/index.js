export * from "./useGlobalStateFunc";
